EXPERIMENTO N-BEATS U24 Y COMPARACIÓN CON HGB
=============================================

Modelo:
M4-NBEATS-U24-DIF-MAE-Global

Entrada:
24 valores horarios anteriores de DIF.

Objetivo:
DIF de la hora siguiente.

Arquitectura:
N-BEATS genérico con 2 stacks, 3 bloques por stack,
3 capas densas por bloque y 128 unidades ocultas.

Selección temporal:
- Subtrain: 4428 observaciones.
- Validación interna: 721.
- Mejor época: 8.
- MAE interno: 26.3145 W/m².

Evaluación externa:
1.464 horas de agosto y septiembre de 2024.

Modelo de comparación:
M3-HGB-9V-DIF-Elevacion-Delta1-AbsoluteError-Global.

Contenido:
- pesos y configuración;
- historial de entrenamiento;
- ventanas secuenciales;
- predicciones;
- métricas;
- comparación pareada;
- diagnóstico de errores;
- episodios extremos;
- figuras.

Pendiente:
La importancia de los 24 retardos todavía no está incluida.
Se calculará en el siguiente bloque mediante permutación temporal.

El parquet minutal original no está incluido.