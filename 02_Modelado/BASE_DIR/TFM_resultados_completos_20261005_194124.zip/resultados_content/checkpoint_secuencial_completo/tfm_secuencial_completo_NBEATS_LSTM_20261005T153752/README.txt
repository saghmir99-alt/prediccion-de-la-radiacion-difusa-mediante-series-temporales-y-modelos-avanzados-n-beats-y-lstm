EXPERIMENTO SECUENCIAL COMPLETO: N-BEATS Y LSTM
==============================================

Este checkpoint contiene de forma reproducible el estudio comparativo de modelos
secuenciales univariantes (N-BEATS y LSTM) frente al baseline HGB-9V.

Contenido del ZIP:
------------------
- tablas_metricas/: Folds de validación temporal, MAE, RMSE, R2, percentiles y análisis por régimen solar.
- datos_predicciones/: Predicciones horarias en CSV y Parquet de todos los modelos en validation (1.464 horas).
- modelos_guardados/: Pesos (.pt) de N-BEATS directo, N-BEATS residual y LSTM.
- figuras/: Gráficos del diagnóstico de errores e importancia por permutación de los 24 retardos.
- configuracion_experimentos.json: JSON con épocas óptimas, escalado de DIF y nombres de modelos.