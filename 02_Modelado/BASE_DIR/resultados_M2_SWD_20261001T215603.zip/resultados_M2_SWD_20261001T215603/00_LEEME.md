# Resultados de la familia M2-Ridge-SWD

Fecha de exportación: 20261001T215603

## Objetivo

Evaluar si las variables históricas de radiación de onda corta descendente
aportan información predictiva adicional a M1-A Ridge-DIF para predecir
DIF(t+1).

## Modelos comparados

- M0-Híbrido: benchmark de persistencia.
- M1-A: cuatro retardos de DIF media.
- M2-SWD-M1: SWD media en t.
- M2-SWD-M24: SWD media en t, t-1, t-2 y t-23.
- M2-SWD-F1: media, mínimo, máximo y std de SWD en t.
- M2-SWD-F3: familia completa en t, t-1 y t-2.
- M2-SWD-F24: familia completa en t, t-1, t-2 y t-23.

## Modelo destacado

M2-SWD-F24 contiene:

- cuatro retardos de DIF;
- cuatro estadísticos de SWD;
- cuatro retardos por estadístico;
- veinte features en total.

## Análisis incluidos

- validación temporal del alpha;
- comparación global;
- comparación completamente diurna;
- comparación por régimen solar;
- MAE, RMSE, sesgo, R² y nMAE;
- coeficientes estandarizados;
- resumen por estadístico y por retardo;
- ablación por bloques;
- figuras;
- predicciones de train y validation;
- dataset derivado reproducible.

## Convenciones temporales

Para predecir DIF(t+1):

- lag1 = t;
- lag2 = t-1;
- lag3 = t-2;
- lag24 = t-23.

## Test

El test permanece cerrado. No se ha utilizado para seleccionar variables,
hiperparámetros ni modelos.

## Datos originales

El parquet minutal original no está incluido. El ZIP contiene el dataset
derivado utilizado para la comparación.