# Checkpoint M3 — Kd e indicadores

Fecha de exportación: 20261002T175603

## Objetivo

Predecir DIF(t+1) utilizando exclusivamente información disponible
hasta el instante t.

## Soporte

- Train: 5,180 observaciones.
- Validation: 1,464 observaciones.
- Test utilizado: no.

## Modelos guardados

1. M2-SWD-F24:
   cuatro retardos de DIF y dieciséis variables de SWD.

2. M3-Kd3:
   M2 más Kd en los retardos 1, 2 y 3.
   Las ausencias se imputan mediante la mediana de train.

3. M3-Kd3-Indicadores:
   M3-Kd3 más indicadores automáticos de ausencia.

4. M3-SoloIndicadores:
   M2 más tres indicadores explícitos de Kd no calculable,
   sin introducir los valores numéricos de Kd.

## Conclusión provisional

Los valores numéricos de Kd no demuestran una mejora incremental
relevante en Ridge. La mejora global procede principalmente de los
indicadores que señalan si SWD era positiva en los retardos recientes.

Los indicadores mejoran el resultado global y completamente diurno,
pero perjudican las horas de transición. M0-Híbrido continúa siendo
claramente superior durante transición y noche.

## Siguiente paso

Evaluar una arquitectura enrutada por el régimen solar conocido de
t+1:

- Ridge supervisado para horas completamente diurnas.
- Persistencia diaria para transición y noche.

Después se comparará un Ridge global aplicado solo al día frente a un
Ridge entrenado exclusivamente con horas completamente diurnas.