# Checkpoint TFM — Ridge y análisis de errores

Fecha: 20261001T212344

## Contenido

- Dataset de modelado utilizado por M0 y M1.
- Dataset ampliado con los retardos de DIF std dev.
- Predicciones de train y validation.
- Análisis global de errores.
- Diagnóstico por régimen solar.
- Diagnóstico por nivel de DIF, hora, mes y rampas.
- Modelos Ridge entrenados.
- Ablación M1-C1, M1-C3 y M1-C24.
- Tablas, figuras y configuraciones.

## Modelos de referencia

- M0-Híbrido: benchmark ingenuo.
- M1-A Ridge-DIF: baseline supervisado.

## Decisión sobre DIF std dev

Las variantes con uno, tres y cuatro retardos de DIF std dev no mejoran
el MAE global ni diurno de M1-A. La variable no se incorpora al baseline
Ridge. Puede conservarse como candidata para modelos no lineales posteriores.

## Estado del test

El test permanece cerrado. No se han calculado métricas nuevas ni se ha
realizado selección utilizando test.

## Parquet original

El parquet minutal original no está incluido porque se conserva localmente
y aumentaría innecesariamente el tamaño del checkpoint.