# Checkpoint del modelado diurno con geometría y ablaciones

Fecha: 20261003T164509

## Estado del trabajo

Se ha construido un especialista Ridge para predecir DIF(t+1) durante
horas completamente diurnas.

El modelo inicial contenía 17 variables:

- cuatro retardos de DIF;
- SWD media, mínimo y desviación en lag3 y lag24;
- tres indicadores de Kd no calculable;
- cuatro elevaciones solares históricas.

## Modelo seleccionado

Nombre:

`M2-R24+Indicadores+ElevHist-Diurno`

Número de variables: 14

Alpha: 0.1

MAE validation diurna:
32.5240 W/m²

RMSE validation diurna:
46.5262 W/m²

R² validation diurna:
0.7786

## Decisión

Se elimina el bloque SWD-lag3:

- SWD_media_lag3;
- SWD_min_lag3;
- SWD_std_lag3.

La eliminación mejora ligeramente tanto la validación temporal como
validation diurna y reduce el modelo de 17 a 14 variables.

No se realizará todavía una segunda ronda de poda, porque la
incorporación de nuevas familias puede redistribuir la aportación de
los predictores actuales.

## Arquitectura provisional

- Completamente diurna: especialista Ridge.
- Transición: persistencia diaria.
- Noche: persistencia diaria.

## Siguiente paso

1. Construir y evaluar el modelo híbrido por regímenes.
2. Congelar sus métricas.
3. Evaluar la aportación incremental de DIR.
4. Continuar con el resto de familias.
5. Realizar la depuración definitiva al final.
6. Comparar posteriormente con modelos no lineales.

## Test

El conjunto test continúa completamente cerrado.