DIAGNÓSTICO DE ERRORES
======================

Modelo:
M3-HGB-8V-DIF-Elevacion-Global

Objetivo:
Determinar dónde falla el modelo seleccionado y comparar
sus errores con M0-Hibrido y M1-Ridge-DIF.

Convención:
error = predicción - observación

- error positivo: sobreestimación;
- error negativo: infraestimación.

Análisis incluidos:
- métricas globales y por régimen;
- población operativa sin noche;
- porcentaje de horas ganadas;
- quintiles de DIF;
- bandas de elevación;
- amanecer frente a atardecer;
- meses;
- errores extremos.

No se ha utilizado el conjunto test.