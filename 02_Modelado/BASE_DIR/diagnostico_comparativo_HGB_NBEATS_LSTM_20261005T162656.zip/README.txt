DIAGNÓSTICO COMPARATIVO HGB, N-BEATS Y LSTM
===========================================

Periodo evaluado
----------------
Validation: 2024-08-01 00:00 UTC a
2024-09-30 23:00 UTC.

Número de observaciones
-----------------------
1.464 horas.

Test
----
El test no se ha abierto ni utilizado.

Modelos principales
--------------------
1. M3-HGB-9V-DIF-Elevacion-Delta1-AbsoluteError-Global
2. M4-NBEATS-U24-DIF-MAE-Global
3. M5-LSTM-U24-DIF-MAE-Global

Modelo secundario
-----------------
M4b-NBEATS-U24-DeltaTarget-MAE-Global

Contrato predictivo
-------------------
Objetivo: DIF de la hora siguiente.
Frecuencia: horaria.
Ventana secuencial: 24 horas.
Predicción causal.

Contenido
---------
- tabla maestra pareada;
- predicciones en CSV y Parquet;
- métricas por contexto;
- diagnóstico de cambios;
- matrices de dirección;
- correlaciones de errores;
- horas ganadas;
- ventajas HGB–LSTM;
- media simple HGB–LSTM;
- límite diagnóstico del oráculo;
- extremos históricos N-BEATS p95;
- extremos simétricos p99;
- grandes rampas;
- figuras;
- modelos entrenados;
- configuración metodológica;
- manifiesto de archivos.

Advertencia sobre el oráculo
----------------------------
El oráculo conoce a posteriori qué modelo produjo el menor
error. No representa un modelo utilizable ni un resultado
predictivo alcanzado. Solo mide el margen máximo de
complementariedad entre los modelos.

Notas
-----
N-BEATS delta se conserva como variante secundaria.
Las conclusiones deben apoyarse principalmente en HGB-9V,
N-BEATS directo y LSTM-U24.