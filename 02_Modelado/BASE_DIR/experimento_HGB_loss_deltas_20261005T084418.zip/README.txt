CHECKPOINT: EXPERIMENTO HGB LOSS × DELTAS
=========================================

Objetivo
--------
Comparar squared_error y absolute_error con:

1. las ocho variables de referencia;
2. la incorporación de delta_DIF_t;
3. la incorporación de los dos deltas recientes de DIF.

Definiciones
------------
delta_DIF_t =
    DIF_lag_1 - DIF_lag_2

delta_DIF_t_menos_1 =
    DIF_lag_2 - DIF_lag_3

Metodología
-----------
- Entrenamiento global.
- Cinco divisiones temporales dentro de train.
- Evaluación final sobre validation.
- Test completamente cerrado.
- MAE como métrica principal.
- Mismo soporte e hiperparámetros para todos los modelos.

Contenido
---------
datos/:
    predicciones de train y validation.

tablas/:
    CV, métricas, selección y mejoras incrementales.

modelos/:
    seis modelos HGB entrenados.

configuracion/:
    inventario y definición del experimento.

figuras/:
    comparación de MAE en validation.