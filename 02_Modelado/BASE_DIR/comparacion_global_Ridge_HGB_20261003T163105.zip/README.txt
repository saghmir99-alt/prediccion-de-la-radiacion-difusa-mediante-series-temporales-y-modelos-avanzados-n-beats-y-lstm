CHECKPOINT: COMPARACIÓN GLOBAL RIDGE–HISTGRADIENTBOOSTING
=========================================================

Objetivo
--------
Comparar modelos lineales y no lineales para predecir
DIF(t+1), sin incorporar todavía la familia DIR.

Modelos
-------
- M0-Hibrido: benchmark ingenuo.
- M1-Ridge-DIF: baseline Ridge con cuatro retardos de DIF.
- M2-Ridge-17V-Global: referencia lineal completa.
- M2-Ridge-14V-Global: referencia lineal compacta.
- M3-HGB-DIF-Global: contraste no lineal mínimo.
- M3-HGB-17V-Global: contraste no lineal con 17 variables.
- M3-HGB-14V-Global: contraste no lineal compacto.

Metodología
-----------
Los modelos se entrenaron globalmente con todas las horas de train.
Los regímenes solares solo se utilizaron para desglosar las métricas.
La selección de hiperparámetros se realizó mediante validación
temporal interna de train.

nMAE
-----
nMAE (%) = 100 × MAE / media(DIF real).

El nMAE puede ser inestable durante la noche porque la media de DIF
es próxima a cero. En ese régimen deben priorizarse MAE y RMSE.

Importante
----------
- No se eliminó la tendencia.
- No se utilizó el conjunto test.
- No se incorporó todavía DIR.
- Las predicciones se guardan en CSV y Parquet.