# Checkpoint del modelado: M0 y Ridge G0

## Estado del análisis

Se ha construido un dataset supervisado para predecir la media horaria
de irradiancia difusa `DIF(t+1)`.

La base comienza el 28/12/2023, después de la discontinuidad detectada
en DIF durante diciembre. Las medias horarias principales requieren
al menos 30 minutos válidos.

## Particiones

- Train: 28/12/2023–31/07/2024.
- Validation: 01/08/2024–30/09/2024.
- Test: 01/10/2024–30/11/2024.

Los intervalos se aplican sobre la hora objetivo.

## Benchmark principal

La persistencia híbrida utiliza:

- persistencia inmediata durante las horas completamente diurnas;
- persistencia diaria en transición y noche.

Resultados globales en validation:

- MAE: 25,662 W/m².
- RMSE: 45,727 W/m².
- Sesgo: −1,471 W/m².

## Ridge G0

Variables introducidas:

- `DIF_lag_1`
- `DIF_lag_2`
- `DIF_lag_3`
- `DIF_lag_24`
- `elevacion_media_objetivo`
- `elevacion_minima_objetivo`
- `elevacion_maxima_objetivo`
- `fraccion_minutos_dia_objetivo`
- `es_diurna_completa_objetivo`
- `es_transicion_objetivo`

Mejor alpha: 10.0

MAE medio en validación temporal interna:
24.921 W/m².

Resultados globales en validation:

- MAE: 21,505 W/m².
- RMSE: 36,794 W/m².
- Sesgo: +0,878 W/m².

Ridge mejora principalmente las horas completamente diurnas, pero
empeora las transiciones y la noche frente a la persistencia diaria.

## Precaución

Las variables geométricas de la hora objetivo son conocidas
anticipadamente y no introducen fuga de información. Sin embargo,
la representación actual contiene variables redundantes.

## Siguiente paso

Comparar tres configuraciones sobre el mismo soporte:

1. Ridge con retardos de DIF exclusivamente.
2. Ridge con retardos y geometría objetivo mínima.
3. Ridge G0 con la geometría objetivo completa actual.

El conjunto de test permanece cerrado.