# Ablación de geometría en Ridge

## Modelos comparados

- M0-Híbrida.
- M1-Ridge-DIF: cuatro retardos de DIF.
- M1-Ridge-GeomMin: retardos más geometría mínima.
- M1-Ridge-GeomFull: retardos más geometría completa.

## Evaluación

Los modelos se comparan sobre soporte común en:

- train;
- validation;
- total;
- horas completamente diurnas;
- transición;
- noche.

El conjunto de test permanece cerrado.

## Contenido

- Métricas completas.
- Comparación global.
- Comparación por régimen.
- Alpha y validación temporal.
- Coeficientes estandarizados.
- Predicciones de train y validation.
- Modelos Ridge entrenados.
- Configuración de variables.