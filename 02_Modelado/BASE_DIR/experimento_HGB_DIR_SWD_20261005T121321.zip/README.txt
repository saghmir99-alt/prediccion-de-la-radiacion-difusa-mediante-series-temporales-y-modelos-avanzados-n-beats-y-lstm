EXPERIMENTO HGB CON DIR Y SWD
=============================

Nombre: experimento_HGB_DIR_SWD_20261005T121321

Objetivo
--------
Comprobar si las medias horarias retardadas de DIR y SWD
aportan información incremental al núcleo HGB congelado.

Modelo de referencia
--------------------
M3-HGB-9V-DIF-Elevacion-Delta1-AbsoluteError-Global

Núcleo
------
- DIF_lag_1
- DIF_lag_2
- DIF_lag_3
- DIF_lag_24
- elevacion_media_lag1
- elevacion_media_lag2
- elevacion_media_lag3
- elevacion_media_lag24
- delta_DIF_t

Variantes estudiadas
--------------------
- DIR lag1
- DIR lags 1, 2 y 3
- DIR lags 1, 2, 3 y 24
- SWD lag1
- SWD lags 1, 2 y 3
- SWD lags 1, 2, 3 y 24

Decisión
--------
Ninguna variante mejora el núcleo en el MAE operacional
de validation. DIR y SWD media se descartan de este núcleo HGB.

Notas
-----
La conclusión se limita al algoritmo, soporte y configuración
evaluados. No implica ausencia de relación física con DIF.

El ZIP no contiene el parquet minutal original.