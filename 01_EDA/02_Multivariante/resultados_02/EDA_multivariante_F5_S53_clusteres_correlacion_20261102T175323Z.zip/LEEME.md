# 5.3 · Clústeres X–X

Entrada única: ZIP de 5.2. Se reutilizan las correlaciones de las 325 parejas del conjunto de entrenamiento; no se usa validation o test.

El árbol agrupa COLUMNAS, no horas. La distancia es 1 menos el valor absoluto de Pearson o Spearman. Correlaciones de signo opuesto pueden quedar en un grupo; la matriz conserva los signos.

La tabla 01 evalúa K=2..16 y muestra silueta y número de grupos unitarios. Ningún máximo de silueta se declara óptimo: el árbol completo es el resultado principal. La tabla 02 indica pertenencias en dos niveles de referencia: distancia 0,10 (|coef.| de 0,90) para núcleos muy estrechos y 0,20 (|coef.| de 0,80) para bloques más amplios. Estos niveles no asignan un número verdadero de familias físicas. La línea violeta en el árbol señala únicamente el nivel 0,10.

La figura 04 muestra, por cada mes, la relación menos intensa entre las parejas de cada núcleo de Spearman en el nivel 0,90. Solo incluye grupos de dos o más variables. Las correlaciones X–X y sus clústeres no demuestran independencia, redundancia predictiva o causalidad.

DIF mínimo, máximo y desviación pertenecen a la misma magnitud y ventana horaria que DIF media. Su uso para estimar DIF media de la misma hora requiere revisar fuga de información. No se eliminan variables ni se ajusta STL en esta subsección.
