# Fase 1 · Subsección 1.1

Ejecución: `20261102T163348Z_ac11f500`.

El ZIP contiene el checkpoint minutal normalizado, tablas estructurales,
configuración, advertencias, resumen e inventario. No se analizaron valores
físicos, distribuciones, correlaciones ni el contenido estadístico del test.

## Recarga en otra sesión de Colab

```python
from google.colab import files
from pathlib import Path
import zipfile
import pandas as pd

subidos = files.upload()  # Selecciona EDA_multivariante_F1_S1_1_20261102T163348Z_ac11f500.zip
nombre_zip = next(iter(subidos))

destino = Path("/content/recarga_1_1")
destino.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(nombre_zip) as z:
    assert z.testzip() is None
    z.extractall(destino)

df_minutal_1_1 = pd.read_parquet(
    destino
    / "checkpoints"
    / "01_datos_minutales_normalizados.parquet"
)

assert df_minutal_1_1.shape == (
    570240,
    31,
)
