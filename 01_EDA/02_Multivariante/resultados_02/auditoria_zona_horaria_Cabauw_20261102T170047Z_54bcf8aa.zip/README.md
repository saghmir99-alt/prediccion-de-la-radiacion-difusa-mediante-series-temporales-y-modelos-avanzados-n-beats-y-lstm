# Fase 4 · Subsección 4.1.1

Auditoría de la referencia horaria del dataset minutal de Cabauw.

Se comparan tres interpretaciones del timestamp: UTC, hora civil
Europe/Amsterdam y CET fijo. La evidencia combina la estructura de la rejilla
en los cambios horarios oficiales y la alineación de SWD con la elevación solar.

Resultado de esta ejecución:

- nivel de evidencia: ORIENTATIVA_REJILLA_CONTINUA;
- mejor hipótesis geométrica: UTC;
- margen orientativo: 0.0482;
- conclusión: Las transiciones disponibles conservan una rejilla continua de 1.440 minutos, sin firma de hora civil. La alineación solar favorece UTC; debe contrastarse con la documentación del proveedor.

Los timestamps originales no se corrigen y no se eliminan ni imputan valores.
Los datos radiométricos de validation y test no se utilizan para puntuar las
hipótesis; octubre de 2024 se inspecciona solo como estructura temporal.
