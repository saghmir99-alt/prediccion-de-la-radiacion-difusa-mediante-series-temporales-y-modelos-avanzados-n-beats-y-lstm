# Fase 2 · Subsección 2.4

Ejecución: 20261102T165224Z_b41d10be

Cribado de posibles cambios instrumentales realizado exclusivamente en
entrenamiento. Se estudian cobertura semanal, resolución aparente mensual,
rachas exactas y cambios persistentes del perfil horario.

Los resultados son indicios para revisión, no pruebas de fallo instrumental.
No se eliminan, imputan, enmascaran ni corrigen observaciones. La zona horaria
y la definición física de DIR continúan pendientes.

Recarga:

1. Extrae este ZIP.
2. Carga checkpoints/07_tabla_horaria_particionada_sin_cambios.parquet.
3. Comprueba que la forma sea (9504, 132).
4. Para repetir los diagnósticos minutales conserva también el ZIP 1.1 cuya
   identidad y SHA-256 figuran en configuracion/configuracion_2_4.json.
