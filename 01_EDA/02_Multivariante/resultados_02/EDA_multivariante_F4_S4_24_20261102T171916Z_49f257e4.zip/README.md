# Subsección 4.2.4 · Descomposición STL/MSTL

Se descompusieron las 27 variables horarias de la partición train mediante:

- STL robusto con periodo diario de 24 horas.
- MSTL robusto con periodos diario (24 h) y semanal (168 h).

No se estimó una estacionalidad anual porque el entrenamiento disponible no cubre
un ciclo anual completo. STL/MSTL exige series sin valores ausentes; por ello se
interpolaron únicamente huecos internos de hasta 24 horas
en copias diagnósticas. El checkpoint incluido en este ZIP es binariamente idéntico
al de entrada y no se aplicó el criterio 30/60.

## Contenido principal

- figuras/01_por_variable/: 27 figuras de ocho paneles.
- figuras/00_resumen/: interpolaciones e índices de fuerza de componentes.
- componentes/01_componentes_STL_MSTL_train.parquet: tendencias,
  estacionalidades y residuos reutilizables para análisis posteriores.
- tablas/: inventario, interpolaciones, índices descriptivos e índice de figuras.
- checkpoints/13_tabla_horaria_con_geometria_solar_sin_cambios.parquet: checkpoint original conservado sin cambios.

Los índices de fuerza son medidas descriptivas acotadas entre 0 y 1; no son
porcentajes de varianza explicada ni pruebas de capacidad predictiva. La
descomposición utiliza suavizadores bilaterales sobre todo train, por lo que sus
componentes no deben incorporarse directamente como predictores de un modelo
prospectivo sin recalcularlas mediante un procedimiento causal.
