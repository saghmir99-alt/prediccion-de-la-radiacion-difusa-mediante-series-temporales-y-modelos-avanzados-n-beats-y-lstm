# Subsección 4.1.2 · Cálculo de la posición solar

## Resultado

Se añadieron al checkpoint horario las siguientes variables deterministas:

- elevacion_solar_deg;
- elevacion_solar_aparente_deg;
- angulo_cenital_solar_deg;
- azimut_solar_deg;
- dia_geometrico y periodo_geometrico.

## Referencia temporal y geográfica

Los timestamps se interpretaron como UTC, conclusión obtenida en la subsección 4.1.1.
La posición se calculó para Cabauw con latitud 51.968, longitud 4.928 y altitud 0.0 m.

dia_geometrico=True significa que la elevación solar geométrica es estrictamente mayor que 0°.

## Alcance de particiones

Las variables solares se calcularon para todas las particiones porque dependen solo del instante y de las coordenadas. Las figuras y los resúmenes descriptivos se elaboraron solo con entrenamiento.

## Protección de datos

No se eliminaron filas, no se imputaron valores y no se utilizaron observaciones radiométricas ni la variable objetivo para calcular la posición solar.
