# 6.3 · Relaciones retardadas entre covariables y DIF

Se comparan X(T−h) y DIF(T), para las 26 covariables y h=1,...,24 horas.
Todos los cálculos usan la misma máscara común de 6.1. Se incluyen las horas
disponibles de diciembre. Los objetivos son diurnos; sus orígenes pueden ser
nocturnos o de transición. No se recalculan retardos sobre filas diurnas comprimidas.

## Lectura

Los tres mapas tienen las mismas filas y columnas. Cada celda representa una
variable y un retardo. Pearson y Spearman utilizan una escala fija de −1 a +1;
MI utiliza su propia escala no negativa en nats. Un coeficiente negativo expresa
dirección inversa, no ausencia de asociación. MI no tiene signo ni máximo de 1.
El gris indica una medida no estimada para una variable constante.

La tabla 01 contiene las 624 combinaciones, sin seleccionar máximos ni aplicar
umbrales. Incluye MI para k=3,5,10, número de ceros, valores distintos y proporción
modal. k=5 es la referencia. Los otros k son sensibilidad, no intervalos de
confianza. La MI se estima como continua: las concentraciones de valores repetidos
requieren prudencia. Una MI positiva no demuestra por sí sola no linealidad y
un cero estimado no prueba independencia.

Las tablas 02–04 son versiones matriciales de las medidas principales. La tabla
05 identifica las horas objetivo. No se incluyen dispersiones: estos mapas
permiten localizar patrones, pero no establecer la forma exacta de las relaciones.

## Alcance

Pearson es una CCF descriptiva calculada como correlación de cada par alineado
en la muestra objetivo diurna. No es una CCF estacionaria convencional con
normalización global. No se aplican pruebas ni bandas automáticas de significación.
Las series originales conservan ciclos y tendencias; el ajuste temporal queda
para 6.4. Las diferencias entre retardos también coinciden con cambios en la
geometría solar de los orígenes, documentados en 6.1.

El horizonte previsto sigue siendo una hora: para T=t+1, h=1 usa X(t) y h=24 usa
X(t−23). Estos resultados no demuestran causalidad, capacidad predictiva fuera
de muestra ni información incremental respecto a DIF histórica. Los estadísticos
retardados de DIF pertenecen al historial del objetivo; su disponibilidad real
depende de que su intervalo haya terminado al emitir la predicción.

No se añade DIF media a las 26 covariables: su memoria ya está estudiada en 6.2.
Conservar el ZIP de 6.1 para los siguientes pasos; este resultado no duplica
su checkpoint. Las conclusiones deben apoyarse en patrones y tablas, sin
seleccionar automáticamente un retardo por el máximo entre 624 combinaciones.
