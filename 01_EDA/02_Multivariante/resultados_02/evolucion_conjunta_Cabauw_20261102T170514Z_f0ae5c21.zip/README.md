# Subsección 4.2.2 · Evolución conjunta durante entrenamiento

## Objetivo

Se generan comparaciones visuales de las 26 variables X frente a `DIF__media_h` en la partición de entrenamiento. El análisis es contemporáneo: X(t) ↔ DIF(t). No estima causalidad ni poder predictivo a una hora vista.

## Figuras generadas

- una figura de referencia con la evolución diaria de DIF y las tres semanas seleccionadas;
- para cada variable X, una figura con series horarias alineadas y evolución diaria agregada;
- para cada variable X, una figura con superposición normalizada y semanas de invierno, primavera y verano.

La agregación diaria es la media de los valores horarios disponibles. La normalización z-score se aplica por separado a cada serie únicamente para comparar su forma; no modifica el checkpoint.

## Integridad y alcance

No se eliminan filas, no se imputan valores y no se aplica el criterio 30/60. Las semanas estacionales son muestras visuales fijas de 168 horas y no se emplean como filtros ni para estimar correlaciones.

Las variables de geometría solar se conservan en el checkpoint, pero se utilizarán específicamente en la subsección 4.2.8 para separar regímenes solares.
