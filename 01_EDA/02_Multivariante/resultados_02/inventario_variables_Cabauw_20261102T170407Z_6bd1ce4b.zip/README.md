# Subsección 4.2.1 · Inventario de variables

## Resultado

Se verificaron 27 variables observacionales horarias:

- 24 radiométricas: media, mínimo, máximo y media horaria de la desviación estándar minutal para SWD, DIR, DIF, LWD, SWU y LWU;
- 3 meteorológicas: medias horarias de T2, RH y PoPoPoPo.

El objetivo contemporáneo es DIF__media_h. Las restantes 26 variables quedan identificadas para las comparaciones X(t) ↔ DIF(t).

## Alcance

Los resúmenes de disponibilidad se elaboran sobre entrenamiento. No se aplicó el criterio 30/60 como filtro ni se modificó el checkpoint.

Las variables de posición solar no forman parte de las 27 comparaciones observacionales. Se reservaron como contexto físico y para la separación por regímenes solares.

## Cautela de interpretación

DIF__min_h, DIF__max_h y DIF__std_media_h se derivan de las mismas observaciones minutales que DIF__media_h. Su relación contemporánea con el objetivo es descriptiva y estructural, no evidencia de capacidad predictiva independiente.
