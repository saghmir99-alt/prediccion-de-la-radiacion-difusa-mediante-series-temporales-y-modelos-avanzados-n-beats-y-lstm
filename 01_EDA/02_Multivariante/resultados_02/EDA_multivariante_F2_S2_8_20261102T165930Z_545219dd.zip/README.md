# Fase 2 · Subsección 2.8

Ejecución: 20261102T165930Z_545219dd

Evaluación detallada del criterio 30/60 para un modelo inicial que utiliza las
nueve familias de variables. Una hora se considera válida cuando cada variable
tiene al menos 30 minutos disponibles. Para una ventana predictiva estricta de
48 horas, todas las familias deben cumplir el criterio en cada uno de los 48
timestamps históricos. El objetivo DIF de t+1 también debe cumplir 30/60.

La subsección separa tres magnitudes que no son equivalentes: cumplimiento de
cada variable por hora, cumplimiento conjunto de las nueve variables por hora y
retención final de ventanas de 48 horas. El umbral se trata como candidato; no se
declara todavía como política definitiva.

Resultado principal de esta ejecución:

- horas de train con las nueve variables válidas: 5,202/5,208
  (99.88%);
- ventanas estrictas de 48 h utilizables: 4,872/5,208
  (93.55%);
- ventanas no utilizables: 336.

Se generan 13 figuras: cuatro resúmenes y nueve fichas individuales, una por
variable. Las tablas conservan los valores exactos que sustentan los gráficos.

No se cargan valores físicos de validation o test, no se materializan lags y no
se elimina, imputa ni corrige ningún dato.
