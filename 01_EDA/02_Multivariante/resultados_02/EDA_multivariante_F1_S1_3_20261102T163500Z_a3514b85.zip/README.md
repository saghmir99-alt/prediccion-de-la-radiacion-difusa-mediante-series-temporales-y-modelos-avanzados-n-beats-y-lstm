# Fase 1 · Subsección 1.3

Ejecución: 20261102T163500Z_a3514b85

El checkpoint contiene la tabla horaria completa con la columna
particion_observacion. Esta etiqueta describe la partición de cada observación
según su propio Date/Time. No representa todavía la partición de ejemplos
supervisados, que se asignará posteriormente según el timestamp de DIF_t+1.

No se han construido lags ni objetivos. No se muestran ni analizan valores
físicos, distribuciones o métricas de test.

Recarga en otra sesión de Colab:

1. Sube este ZIP con google.colab.files.upload().
2. Extráelo con zipfile.ZipFile en una carpeta nueva.
3. Carga checkpoints/03_tabla_horaria_con_particion_observacion.parquet.
4. Comprueba que la forma sea (9504, 132).
