# Fase 2 · Subsección 2.6

Ejecución: 20261102T165730Z_3fe4c1f3

Cuantificación descriptiva de la pérdida potencial de ventanas históricas de
48 horas según las familias disponibles, exclusivamente para objetivos de train.

Se comparan dos criterios: (1) media horaria finita y (2) media finita con al
menos 54 de 60 minutos disponibles. El segundo es un umbral provisional de
sensibilidad y no una regla automática de descarte.

Las 48 horas de historia pueden proceder de pre_segmento o train, pero siempre
son anteriores al objetivo. No se cargaron valores de validation ni test. No se
materializaron lags ni DIF_t+1 y no se eliminaron, imputaron o corrigieron datos.

Recarga:

1. Extrae este ZIP.
2. Usa checkpoints/09a_tabla_horaria_particionada_sin_cambios.parquet para la
   tabla horaria original.
3. Usa checkpoints/09b_catalogo_ventanas_estructurales_48h_sin_cambios.parquet
   para el catálogo estructural original.
4. Usa checkpoints/09c_catalogo_disponibilidad_ventanas_train.parquet para las
   máscaras y conteos de disponibilidad de train.
5. Verifica los SHA-256 en configuracion/configuracion_2_6.json.
