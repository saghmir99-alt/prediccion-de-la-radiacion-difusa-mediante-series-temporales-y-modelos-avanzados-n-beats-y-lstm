# 6.1 · Preparación de relaciones retardadas

Entrada única: `EDA_multivariante_5_2_evolucion_mensual_xx_20261102T174456Z.zip`. Tiempo UTC. Solo train.

- Horas observadas de train: 5208.
- Huecos insertados en la rejilla, sin imputación: 0.
- Objetivos completamente diurnos: 2588.
- Objetivos de la muestra común: 2570.
- Exclusiones de la muestra común: 18; consultar tabla 04.

## Convención y uso

Cada fila tiene un objetivo DIF(T) y columnas X(T-h), para h=1,2,...,24 horas.
El horizonte previsto es una hora: si t es la última hora agregada disponible, T=t+1;
h=1 usa X(t) y h=24 usa X(t-23). La etiqueta de inicio o fin de intervalo y el
tiempo real de disponibilidad deben respetarse al implantar la predicción.

El Parquet de pares conserva TODOS los objetivos diurnos. Para las comparaciones
principales de 6.2 y 6.3, seleccionar `muestra_principal_comun == True`.
Los 27 predictores son las 26 covariables anteriores y DIF media retardada.
`DIF__media_h` sin sufijo lag es exclusivamente la respuesta.
Las columnas geométricas y de timestamp son de auditoría, no nuevos predictores.

El desplazamiento se construye con timestamps de la cronología horaria completa,
antes de seleccionar los objetivos diurnos. No se unen artificialmente tardes
y mañanas. No se aprovechan filas de pre_segmento, validación o test.
Se admiten predictores de noche y transición: eran observables antes del objetivo.
El filtro diurno describe el objetivo, no elimina el ciclo solar.

La tabla 01 diferencia disponibilidad por pareja y uso en la muestra común.
La tabla 02 mantiene diciembre e indica su cobertura parcial; esa descripción
no justifica tratarlo como un mes completo en futuras comparaciones mensuales.
La tabla 03 clasifica los orígenes de los predictores sobre la muestra común.
La figura contiene dos paneles de disponibilidad, sin métricas de asociación.

Para análisis posteriores se necesita únicamente ESTE ZIP. Incluye el checkpoint
horario de train, manteniendo las columnas originales y añadiendo la marca de hora
observada. No es el checkpoint original intacto: se ha limitado a train y, si
existían huecos, se han representado mediante filas ausentes. No hay imputación.
Los futuros diagnósticos sobre residuos/filtros tendrán que recalcular su soporte
válido y comparar series originales y ajustadas en las mismas horas.
