# Fase 2 · Subsección 2.1

Ejecución: 20261102T163533Z_3f784d6b

Se estudian ausencias y cobertura únicamente en las 5208 horas de
entrenamiento. Disponible significa no ausente y no implica todavía validez
física. No se eliminan filas, no se imputan valores y no se enmascaran agregados.

Validation y test no se analizan. El checkpoint es una copia lógica sin cambios
de la tabla horaria particionada recibida de la subsección 1.3.

Recarga:

1. Sube este ZIP en Colab.
2. Extráelo en una carpeta nueva con zipfile.ZipFile.
3. Carga checkpoints/04_tabla_horaria_particionada_sin_cambios.parquet.
4. Comprueba que la forma sea (9504, 132).
