# 6.4 · Contraste tras ajuste STL

Se reutiliza STL robusto diario del ZIP 4.2.4, sin ajustar otra descomposición.
Los originales se contrastan con los guardados junto a las componentes. Se
enmascaran residuos de observaciones interpoladas/no finitas. La interpolación
diagnóstica pudo influir en componentes vecinas: el enmascaramiento no elimina
esa influencia del ajuste ya realizado. No se aplica MSTL ni preblanqueamiento.

## Comparación

Originales y residuos usan EXACTAMENTE los mismos objetivos diurnos en todos
los retardos 1–24 y variables. La respuesta ajustada es residuo_DIF(T) y la entrada
residuo_X(T−h). Se recalculan originales sobre esta intersección, no se restan
métricas procedentes de muestras diferentes. Las tablas incluyen todas las
624 combinaciones y MI k=3,5,10; las figuras muestran k=5 como referencia.

Las diferencias son residuo menos original. En Pearson/Spearman también se
exporta delta_abs: negativo indica menor magnitud de correlación. Una diferencia
firmada negativa puede significar una relación más negativa, no una atenuación.
MI puede aumentar o disminuir; no hay signo de dependencia ni escala máxima 1.
STL cambia la variable analizada; las diferencias no son porcentajes causales
de información eliminada. La sensibilidad a k no es un intervalo de confianza.

## Diagnósticos

La autocorrelación residual se calcula por pares finitos a 1–24 horas sobre
la rejilla horaria COMPLETA de train, incluida la noche. No se comprimen huecos.
No se añaden bandas clásicas ni se declara ruido blanco por coeficientes pequeños.
La tabla mensual incluye diciembre parcial; la figura muestra meses completos.
Mediana e IQR se dividen por la desviación global de cada residuo para comparar
cambios relativos dentro de cada variable. No es una prueba de estacionariedad
ni un estudio de la estabilidad mensual de las relaciones X–DIF.

## Límites

STL retira componentes estimadas, no controla completamente geometría solar,
estación o meteorología. Los residuos pueden conservar autocorrelación. La
descomposición es retrospectiva sobre todo train, incluye suavizado bilateral y
efectos de borde; estos residuos son diagnósticos, no entradas causales listas
para predecir fuera de muestra. No hay demostración de causalidad ni ganancia
predictiva incremental. El preblanqueamiento solo se considerará después para
una duda concreta. No se seleccionan variables ni retardos automáticamente.
