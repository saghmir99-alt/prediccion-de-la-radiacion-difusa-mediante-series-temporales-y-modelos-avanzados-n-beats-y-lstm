# Fase 2 · Subsección 2.2

Ejecución: 20261102T163618Z_d35d4c19

Se analizan exclusivamente las 5208 horas de entrenamiento para
describir rachas consecutivas y patrones de ausencia conjunta. Se distinguen
menos de 54/60 minutos, menos de 60/60 y 0/60 minutos disponibles.

La coocurrencia es descriptiva y no implica una causa común. No se eliminan,
imputan, enmascaran ni corrigen valores. Validation y test no se analizan.

Recarga:

1. Sube este ZIP en Colab.
2. Extráelo en una carpeta nueva con zipfile.ZipFile.
3. Carga checkpoints/05_tabla_horaria_particionada_sin_cambios.parquet.
4. Comprueba que la forma sea (9504, 132).
