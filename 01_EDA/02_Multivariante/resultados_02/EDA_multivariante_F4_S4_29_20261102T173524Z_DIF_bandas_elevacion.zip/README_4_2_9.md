# Apartado 4.2.9

## Comportamiento de DIF por bandas de elevación solar

El apartado 4.2.8 queda temporalmente en standby.

La fila horaria etiquetada como t representa el intervalo
[t,t+60 min). Para cada hora se calcularon 60 posiciones
solares, desde t hasta t+59 minutos.

El análisis utiliza exclusivamente la partición train:
5,208 horas.

Bandas:
- noche;
- 0–10 grados;
- 10–20 grados;
- 20–30 grados;
- 30–40 grados;
- 40–50 grados;
- más de 50 grados.

El ZIP contiene:
- el checkpoint de entrada sin modificar;
- un checkpoint enriquecido con geometría y bandas;
- tablas descriptivas;
- cinco figuras estáticas;
- listados diagnósticos de valores negativos, horas de
  transición y DIF elevada durante la noche.

No se han calculado Kc, Kt ni Kd.
No se han generado violinplots.
No se ha generado visualización interactiva.
No se han imputado ni eliminado observaciones.

Referencia:

Smith, C. J., Bright, J. M. y Crook, R. (2017).
Cloud cover effect of clear-sky index distributions and
differences between human and automatic cloud observations.
Solar Energy, 144, 10–21.
https://doi.org/10.1016/j.solener.2016.12.055