# Fase 2 · Subsección 2.3

Ejecución: 20261102T164510Z_b40245b3

Auditoría algebraica de media, mínimo, máximo, desviación estándar y rango,
realizada exclusivamente en entrenamiento a nivel minutal y horario.

La tolerancia de 1e-09 W/m² es únicamente numérica. No se
aplican límites físicos, no se corrigen datos y no se analiza validation o test.

El checkpoint minutal no se duplica; su ZIP y SHA constan en la configuración.
El checkpoint horario de salida es idéntico al recibido de 2.2.

Recarga:

1. Extrae este ZIP.
2. Carga checkpoints/06_tabla_horaria_particionada_sin_cambios.parquet.
3. Comprueba que la forma sea (9504, 132).
4. Para reproducir la parte minutal conserva también el ZIP 1.1 identificado
   en configuracion/configuracion_2_3.json.
