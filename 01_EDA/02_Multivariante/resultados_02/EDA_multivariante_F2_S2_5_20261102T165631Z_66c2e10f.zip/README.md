# Fase 2 · Subsección 2.5

Ejecución: 20261102T165631Z_66c2e10f

Auditoría exclusivamente estructural de la disponibilidad de ventanas
históricas de 48 horas para un horizonte de una hora.

No se cargaron valores físicos: únicamente Date/Time y particion_observacion.
Validation y test se utilizaron solo para comprobar la posibilidad estructural
de construir ventanas. No se materializaron lags ni valores de DIF_t+1.

Recarga:

1. Extrae este ZIP.
2. Carga checkpoints/08a_tabla_horaria_particionada_sin_cambios.parquet para
   recuperar la tabla horaria completa.
3. Carga checkpoints/08b_catalogo_ventanas_estructurales_48h.parquet para
   recuperar el catálogo estructural.
4. Verifica sus SHA-256 en configuracion/configuracion_2_5.json.
