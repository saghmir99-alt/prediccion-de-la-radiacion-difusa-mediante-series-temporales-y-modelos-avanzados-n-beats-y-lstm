# 6.2 · Memoria temporal de DIF

Leer primero la tabla 01 y figura 01: mismo conjunto de objetivos en todos los retardos.
Pearson y Spearman indican dirección e intensidad lineal/monótona. MI no tiene signo
ni está limitada a 1; k=5 es la referencia y k=3,10 comprueban sensibilidad del estimador.
La sensibilidad a k no es un intervalo de confianza. MI positiva no prueba por sí sola
no linealidad; cero estimado tampoco prueba independencia. Los empates y ceros del
origen, registrados por retardo, aconsejan cautela con la estimación continua de MI.

Figura 02: retardos 1,6,24 elegidos previamente para representar última hora,
extremo de historia reciente y día anterior. Mismos ejes y colores; no se recortan
observaciones. Las medianas se agrupan en hasta ocho cuantiles de X, reducidos si hay
empates. P10–P90 mide dispersión, no incertidumbre de las medianas. La diagonal es
igualdad de valores, no un ajuste. Consultar tabla 02 para recuentos y extremos.

Los retardos se calculan en horas reales y las horas objetivo son diurnas. La
proporción de orígenes nocturnos cambia con h; no se controla aquí la geometría solar.
No se concluye causalidad, memoria meteorológica pura, optimalidad de retardos,
significación, estabilidad mensual ni mejora predictiva fuera de muestra.
El análisis temporalmente ajustado corresponde a 6.4. No hay bandas clásicas ±1.96/√N.
Para 6.3 se utilizará de nuevo el ZIP de 6.1, que contiene las 26 covariables.
