# Fase 1 · Subsección 1.2

Ejecución: 20261102T163434Z_dc589e0b

Este paquete contiene la tabla horaria construida sobre la rejilla cronológica
completa. Todavía no incorpora la columna de partición. Los agregados con menos
de 54 observaciones no se eliminan ni se enmascaran: quedan acompañados por sus
conteos, proporciones e indicadores de cobertura.

No se muestran ni analizan valores físicos, distribuciones o métricas de test.

Recarga en otra sesión de Colab:

1. Sube este ZIP con google.colab.files.upload().
2. Extráelo en una carpeta nueva usando zipfile.ZipFile.
3. Carga checkpoints/02_tabla_horaria_sin_particion.parquet con pandas.read_parquet().
4. Comprueba que la forma sea (9504, 131).
