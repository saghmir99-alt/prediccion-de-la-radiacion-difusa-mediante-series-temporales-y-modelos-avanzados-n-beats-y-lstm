# Fase 2 · Subsección 2.7

Ejecución: 20261102T165824Z_3d765298

Análisis descriptivo de sensibilidad de la disponibilidad para objetivos de train,
con historia de 48 horas y horizonte de 1 hora. Se comparan ocho umbrales de
minutos disponibles y seis tolerancias de timestamps deficientes por ventana.

Se separan dos casos: (1) tolerar únicamente horas parciales, conservando al
menos un minuto por hora, y (2) tolerar también horas 0/60. El segundo caso es
solo un límite de retención potencial: exige una estrategia posterior de máscara,
imputación o un modelo que admita valores ausentes.

No se selecciona una política final, no se cargan valores físicos de validation
ni test, no se materializan lags y no se elimina, imputa o corrige ningún dato.

Recarga:

1. Extrae este ZIP.
2. Consulta figuras/ para la interpretación visual.
3. Consulta tablas/ para los valores exactos que sustentan cada figura.
4. Usa checkpoints/10d_catalogo_sensibilidad_disponibilidad_train.parquet para
   recuperar los conteos de sensibilidad por objetivo sin cargar valores físicos.
5. Verifica los SHA-256 en configuracion/configuracion_2_7.json.
