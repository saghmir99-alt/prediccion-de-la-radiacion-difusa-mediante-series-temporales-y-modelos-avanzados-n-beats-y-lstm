# Subsección 4.2.5 · Comparaciones contemporáneas X(t) ↔ DIF(t)

Se comparó cada una de las 26 variables X con la media horaria de DIF utilizando
exclusivamente las 5,208 horas de la partición train.

## Procedimiento

Para cada variable se utilizaron únicamente los pares X–DIF finitos, sin
imputación ni aplicación del criterio 30/60. Se generaron:

- un hexbin con densidad de observaciones en escala logarítmica;
- la mediana de DIF por intervalos cuantílicos adaptativos de X;
- bandas P25–P75 y P10–P90;
- una curva LOWESS robusta ajustada sobre las medianas de los intervalos;
- el número de observaciones utilizado en cada intervalo.

## Contenido

- figuras/00_resumen/: resumen de las 26 curvas por percentiles de X.
- figuras/01_por_variable/: 26 comparaciones individuales.
- tablas/01_inventario_26_comparaciones.csv: variables analizadas.
- tablas/02_cobertura_pares_finitos_train.csv: cobertura específica de cada par.
- tablas/03_estadisticos_DIF_por_intervalos_X.csv: medianas, bandas y conteos.
- tablas/04_curvas_LOWESS_medianas.csv: puntos de las curvas suavizadas.
- tablas/05_indice_figuras.csv: correspondencia entre variables y figuras.
- checkpoints/13_tabla_horaria_con_geometria_solar_sin_cambios.parquet: checkpoint original conservado sin cambios.

## Alcance

Las relaciones son contemporáneas, X(t) ↔ DIF(t). Permiten describir formas
lineales o no lineales, saturaciones, umbrales, agrupaciones y cambios de
dispersión, pero no demuestran causalidad ni capacidad para predecir DIF(t+1).

En las variables radiométricas, las horas nocturnas y la geometría solar pueden
generar asociaciones comunes o cúmulos próximos a cero. La separación por
regímenes de elevación solar se reserva para la subsección 4.2.8. Debido a la
autocorrelación temporal, las observaciones tampoco deben tratarse como pares
estadísticamente independientes.
