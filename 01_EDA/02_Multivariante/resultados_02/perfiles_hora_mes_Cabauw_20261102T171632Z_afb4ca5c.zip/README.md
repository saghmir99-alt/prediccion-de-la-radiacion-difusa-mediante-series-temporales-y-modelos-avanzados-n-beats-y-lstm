# Subsección 4.2.3 · Perfiles hora × mes

## Objetivo

Se describen los perfiles de hora UTC × mes UTC de DIF__media_h y de
cada una de las 26 variables X en entrenamiento. El propósito es identificar
patrones diarios y estacionales, variabilidad entre días y soporte de datos,
sin realizar todavía selección de predictores.

## Figuras

- una figura de referencia para DIF: media, dispersión, número de observaciones
  y cobertura por hora y mes;
- una figura de seis paneles para cada comparación X(t) ↔ DIF(t): medias de X
  y DIF, dispersiones de X y DIF, número de pares y cobertura de pares;
- una figura resumen de cobertura por variable y mes.

Las medias y dispersiones de cada pareja se calculan sobre las mismas horas
con X y DIF finitos. La dispersión es la desviación estándar poblacional de
los valores horarios de los distintos días que comparten mes y hora UTC.

## Integridad y alcance

No se eliminan filas, no se imputan valores y no se aplica el criterio 30/60.
La partición continúa siendo exclusivamente train. Los resultados describen
relaciones contemporáneas y no permiten inferir causalidad, nubosidad ni poder
predictivo a una hora vista.

La columna de diciembre de 2023 es parcial porque el entrenamiento comienza el
28 de diciembre; por ello siempre debe interpretarse junto con los paneles de
número de pares y cobertura.
