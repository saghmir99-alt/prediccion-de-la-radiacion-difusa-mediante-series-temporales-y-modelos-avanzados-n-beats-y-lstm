# Subsección 4.2.6 · Detección de relaciones no lineales

## Alcance

Se cuantifica la dependencia contemporánea entre cada una de las 26 variables
X y DIF__media_h utilizando exclusivamente las 5,208 horas de
entrenamiento. Se calculan Pearson, Spearman e información mutua mediante un
estimador de vecinos próximos.

Pearson describe asociación lineal y Spearman asociación monótona. La
información mutua detecta dependencias más generales, pero no proporciona
dirección, no es un porcentaje de varianza explicada y su magnitud depende del
estimador. Por ello se informa en nats y se comprueba su sensibilidad con
k=3, 5 y 10.

## Estabilidad temporal

Las tres métricas se recalculan por meses completos con k=5 para MI. Los meses
incluidos son: 2024-01, 2024-02, 2024-03, 2024-04, 2024-05, 2024-06, 2024-07. Diciembre de 2023 no se utiliza en
esta comparación porque train solo contiene sus cuatro últimos días.

## Integridad

Cada variable utiliza su propia máscara de pares X–DIF finitos. No se imputan
valores, no se eliminan filas y no se aplica el criterio 30/60. El checkpoint
se copia sin reescribirlo y se verifica mediante SHA-256.

## Interpretación

Los resultados son un cribado descriptivo global. Las métricas mezclan
estructura solar, evolución temporal y estados atmosféricos; no demuestran
causalidad ni utilidad predictiva a una hora vista. No se calculan p-valores
bajo independencia porque las observaciones horarias forman una serie
temporal. La separación por regímenes solares se reserva para 4.2.8.
