# Subsección 4.2.7 · Relaciones contemporáneas entre anomalías STL

## Alcance

Se comparan los residuos STL de cada una de las 26 covariables
con el residuo STL de `DIF__media_h`. El análisis utiliza exclusivamente las
5,208 horas de entrenamiento.

Para cada serie se ajusta STL robusta con periodo diario de
24 horas:

`X(t) = tendencia(t) + estacionalidad_24h(t) + residuo(t)`

El objetivo es comprobar qué asociaciones contemporáneas permanecen después
de retirar la evolución de fondo y el ciclo diario estimados. Esta operación
no equivale a eliminar físicamente toda la geometría solar.

## Comparación original–residual

Las métricas originales proceden directamente de las tablas de la subsección
4.2.6. Se calculan sobre los residuos Pearson, Spearman e información mutua
con k=3, 5 y 10. También se repite el análisis por los meses completos de enero
a julio de 2024 con k=5.

## Integridad y valores ausentes

Cada relación utiliza su propia máscara de pares finitos. Los cuatro valores
LWD originalmente ausentes se interpolan únicamente en copias internas para
ajustar STL; sus residuos se restauran como NaN antes del análisis. No se
modifica el checkpoint, no se eliminan filas y no se aplica el criterio 30/60.

## Interpretación

Una relación residual persistente indica asociación entre desviaciones
respecto a los patrones temporales estimados. No demuestra causalidad,
capacidad predictiva a una hora ni información complementaria frente a otras
variables. La separación explícita por regímenes solares corresponde a la
subsección 4.2.8.
