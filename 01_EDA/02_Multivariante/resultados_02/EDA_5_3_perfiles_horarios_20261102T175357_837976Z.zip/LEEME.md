# 5.3 · Cómo leer los resultados

## Muestra

- Horas de train: 5208.
- Horas completamente diurnas: 2588.
- Horas excluidas por algún valor no finito en las 26 variables: 1.
- Horas comunes utilizadas: **2587**. No se imputan valores.
- La muestra global conserva también las horas diurnas disponibles de diciembre.
- Las medias y desviaciones para estandarizar se calculan solo en esta muestra de train.

## Lectura de las figuras

**01 · Dendrograma.** Cada extremo representa una variable. Una unión cercana a cero
indica perfiles parecidos. Para unir dos bloques, el enlace completo utiliza la mayor
distancia entre sus parejas. Una unión tardía no representa necesariamente un grupo
cohesionado: el árbol termina uniendo todas las variables por construcción. La posición
arriba/abajo no es una jerarquía de importancia. No se fija un número de grupos.

**02 · Matriz.** El orden coincide con la lectura del árbol de arriba abajo. Azul oscuro
indica menor distancia. La diagonal es cero porque cada variable se compara consigo misma.
Los cuadrados oscuros a lo largo de la diagonal ayudan a localizar bloques parecidos.

## Tablas

**01 · Vecina más parecida:** una fila por variable, con su vecina de menor distancia.
Si hay empates se muestran todas. Las vecindades no tienen por qué ser recíprocas.
Esta tabla no asigna grupos; el árbol muestra la organización jerárquica.
Incluye la media y desviación utilizadas, para reproducir la estandarización.

**02 · Todas las parejas:** las 325 distancias exactas, ordenadas de menor a mayor.

## Qué significa la distancia

Primero cada serie se centra y se divide por su desviación. Después se promedian las
diferencias absolutas entre las dos series en las mismas horas. Por ejemplo, 0,20
significa una diferencia media de 0,20 unidades en la escala estandarizada. No significa
un 20 % ni una correlación de 0,80. No existe aquí un umbral universal de semejanza.

Las series con evolución opuesta pueden quedar lejos aunque estén muy relacionadas.
Las diferencias de nivel y de escala originales se eliminan al estandarizar.
Los ciclos solares y la evolución estacional siguen presentes. Este análisis mide
semejanza contemporánea de perfiles; no demuestra redundancia predictiva ni causalidad.
Los descriptores mínimo, máximo y std de DIF proceden de la misma hora que DIF media.
Su agrupación no justifica su disponibilidad como predictores del objetivo.

## Vecinas de las 26 variables

| Variable | Vecina más parecida | Distancia |
| --- | --- | ---: |
| Presión media | DIR mín | 0.958 |
| DIR mín | SWU mín | 0.612 |
| DIR media | SWU media | 0.544 |
| DIR std | SWU std | 0.145 |
| SWU std | SWD std | 0.073 |
| SWD std | SWU std | 0.073 |
| LWU std | SWD std | 0.355 |
| SWU media | SWD media | 0.102 |
| SWD media | SWU media | 0.102 |
| SWD máx | SWU máx | 0.112 |
| SWU máx | SWD máx | 0.112 |
| DIR máx | SWU máx | 0.456 |
| SWU mín | SWD mín | 0.105 |
| SWD mín | SWU mín | 0.105 |
| DIF mín | SWD mín | 0.481 |
| DIF máx | SWD máx | 0.431 |
| DIF std | SWD std | 0.485 |
| LWD std | DIF std | 0.575 |
| LWU máx | LWU media | 0.127 |
| LWU media | LWU mín | 0.116 |
| LWU mín | LWU media | 0.116 |
| T2 media | LWU mín | 0.168 |
| LWD máx | LWD media | 0.226 |
| LWD media | LWD mín | 0.226 |
| LWD mín | LWD media | 0.226 |
| RH media | LWD media | 1.056 |
